# -*- coding: utf-8 -*-
import os
import sys
import streamlit as st
import oracledb

# --- AJUSTE DE PATH ---
PASTA_DOT_STREAMLIT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".streamlit"))
if PASTA_DOT_STREAMLIT not in sys.path:
    sys.path.append(PASTA_DOT_STREAMLIT)

import auth_ui
from views import inicio, grafico, pagamento, responsavel, arquivos, usuarios

st.set_page_config(page_title="FOLHA - Operacao NTGD", layout="wide")

# Inicialização de estado
if "autenticado" not in st.session_state: st.session_state.autenticado = False

# --- TRAVA DE LOGIN (Blindada e segura) ---
if not st.session_state.autenticado:
    with st.sidebar:
        auth_ui.gerenciar_sessao_fluxo()
    st.markdown("<h3 style='color: #666; font-weight: normal; margin-top: 5rem; text-align: center;'>🔒 Aguardando identificação no menu lateral...</h3>", unsafe_allow_html=True)
    st.stop()

# --- SIDEBAR: SELEÇÃO DE COMPETÊNCIA ---
with st.sidebar:
    st.write(f"👤 **{st.session_state.get('nome_usuario', 'User')}**")
    st.divider()
    
    ano_selecionado = st.selectbox("Ano de Referência:", [2025, 2026], index=1)
    meses_disponiveis = {
        "01": "Janeiro", "02": "Fevereiro", "03": "Março", "04": "Abril", 
        "05": "Maio", "06": "Junho", "07": "Julho", "08": "Agosto", 
        "09": "Setembro", "10": "Outubro", "11": "Novembro", "12": "Dezembro"
    }
    mes_chave = st.selectbox("Mês de Referência:", options=list(meses_disponiveis.keys()), format_func=lambda x: meses_disponiveis[x], index=4)
    st.divider()
    
    # Navegação
    perfil = st.session_state.get('perfil_usuario', 'c')
    opcoes_menu = ["Inicio", "Grafico", "Pagamento", "Responsavel", "Arquivos/ID"]
    if perfil in ['a', 'g']: opcoes_menu.append("Usuários")
    menu_opcao = st.radio("Navegação:", opcoes_menu)
    
    st.divider()
    if st.button("Sair (Logout)", use_container_width=True, type="secondary"):
        st.session_state.clear()
        st.rerun()

# --- CONEXÃO E RENDERIZAÇÃO DAS VIEWS ---
try:
    conn = oracledb.connect(
        user=st.secrets["database"]["db_user"],
        password=st.secrets["database"]["db_pass"],
        dsn=st.secrets["database"]["db_dsn"]
    )
    
    # Passando ano e mês para todas as views
    if menu_opcao == "Inicio": 
        inicio.render(conn, ano_selecionado, mes_chave, meses_disponiveis)
    elif menu_opcao == "Grafico": 
        grafico.render(conn, ano_selecionado, mes_chave, meses_disponiveis)
    elif menu_opcao == "Pagamento": 
        pagamento.render(ano_selecionado, mes_chave)
    elif menu_opcao == "Responsavel": 
        responsavel.render(conn, ano_selecionado, mes_chave, meses_disponiveis)
    elif menu_opcao == "Arquivos/ID": 
        arquivos.render(conn, ano_selecionado, mes_chave, meses_disponiveis)
    elif menu_opcao == "Usuários" and perfil in ['a', 'g']: 
        usuarios.render(conn, perfil)
    
    conn.close()
except Exception as e:
    st.error(f"Erro de conexão: {e}")

