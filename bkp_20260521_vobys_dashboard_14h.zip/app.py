# -*- coding: utf-8 -*-
import os
import sys
import streamlit as st
import oracledb

PASTA_STREAMLIT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".streamlit"))
if PASTA_STREAMLIT not in sys.path:
    sys.path.append(PASTA_STREAMLIT)

import auth_ui

# --- INTERCEPTAÇÃO DE SESSÃO VIA URL (Blindagem contra F5) ---
params = st.query_params
if "token_auth" in params and params["token_auth"] == "ativo":
    st.session_state.autenticado = True
    st.session_state.usuario_logado = params.get("user", "")
    st.session_state.nome_usuario = params.get("nome", "")
    st.session_state.perfil_usuario = params.get("perfil", "c")
else:
    if "autenticado" not in st.session_state:
        st.session_state.autenticado = False

if "usuario_em_reset" not in st.session_state:
    st.session_state.usuario_em_reset = None

st.set_page_config(
    page_title="FOLHA - Operacao NTGD", 
    layout="wide", 
    initial_sidebar_state="expanded"
)

# Trava de alteração de senha
if st.session_state.usuario_em_reset is not None:
    with st.sidebar:
        auth_ui.gerenciar_sessao_fluxo()
    st.markdown("<h3 style='color: #c62828; font-weight: normal; margin-top: 5rem; text-align: center;'>⚠️ Alteração de Senha Obrigatória no Menu Lateral</h3>", unsafe_allow_html=True)
    st.stop()

# Trava de login
if not st.session_state.autenticado:
    with st.sidebar:
        auth_ui.gerenciar_sessao_fluxo()
    st.markdown("<h3 style='color: #666; font-weight: normal; margin-top: 5rem; text-align: center;'>🔒 Aguardando identificação no menu lateral...</h3>", unsafe_allow_html=True)
    st.stop()

# Estilos CSS
st.markdown("""
    <style>
        .block-container { padding-top: 3.5rem !important; padding-bottom: 1rem !important; padding-left: 2rem !important; padding-right: 2rem !important; }
        h1 { margin-top: 2rem !important; font-size: 36px !important; margin-bottom: 1.5rem !important; }
        div[data-testid="stTable"] table tbody tr td { font-size: 20px !important; font-weight: bold !important; }
        section[data-testid="stSidebar"] div.st-emotion-cache-6qobrx { padding-top: 2rem !important; }
    </style>
""", unsafe_allow_html=True)

try:
    DB_USER = st.secrets["database"]["db_user"]
    DB_PASS = st.secrets["database"]["db_pass"]
    DB_DSN = st.secrets["database"]["db_dsn"]
except Exception as e:
    st.error(f"Erro Secrets: {e}")
    st.stop()

from views import inicio, grafico, pagamento, responsavel, arquivos, usuarios

perfil_logado = st.session_state.get('perfil_usuario', 'c')

# MENU LATERAL DINÂMICO
with st.sidebar:
    st.markdown("<h2 style='color: #015494; margin-top: -1rem;'>NTGD</h2>", unsafe_allow_html=True)
    nome_bruto = st.session_state.get('nome_usuario', '').strip()
    if not nome_bruto:
        nome_bruto = st.session_state.get('usuario_logado', 'Usuário').capitalize()
        
    partes_nome = nome_bruto.split()
    nome_exibicao = f"{partes_nome[0]} {partes_nome[1]}" if len(partes_nome) >= 2 else nome_bruto
    if len(nome_exibicao) > 20: nome_exibicao = nome_exibicao[:20]
        
    st.write(f"👤 **{nome_exibicao}**")
    st.divider()
    st.write("**Filtros do Periodo**")
    anos_disponiveis = [2024, 2025, 2026, 2027]
    ano_selecionado = st.selectbox("Selecione o Ano:", anos_disponiveis, index=2)
    meses_disponiveis = {"01": "Janeiro", "02": "Fevereiro", "03": "Marco", "04": "Abril", "05": "Maio", "06": "Junho", "07": "Julho", "08": "Agosto", "09": "Setembro", "10": "Outubro", "11": "Novembro", "12": "Dezembro"}
    mes_chave = st.selectbox("Selecione o Mes:", list(meses_disponiveis.keys()), format_func=lambda x: meses_disponiveis[x], index=4)
    st.divider()
    st.write("**Navegacao**")
    
    opcoes_menu = ["Inicio", "Grafico", "Pagamento", "Responsavel", "Arquivos/ID"]
    if perfil_logado in ['a', 'g']:
        opcoes_menu.append("Usuários")

    menu_opcao = st.radio("", opcoes_menu)
    st.container(height=180, border=False)
    st.divider()
    
    if st.button("Sair (Logout)", use_container_width=True, type="secondary"):
        st.query_params.clear() # Limpa a URL ao sair
        st.session_state.clear()
        st.session_state.autenticado = False
        st.rerun()

# RENDER DAS VIEWS
try:
    conn = oracledb.connect(user=DB_USER, password=DB_PASS, dsn=DB_DSN)
    if menu_opcao == "Inicio": inicio.render(conn, ano_selecionado, mes_chave, meses_disponiveis)
    elif menu_opcao == "Grafico": grafico.render(conn, ano_selecionado, mes_chave, meses_disponiveis)
    elif menu_opcao == "Pagamento": pagamento.render(ano_selecionado, mes_chave)
    elif menu_opcao == "Responsavel": responsavel.render(conn, ano_selecionado, mes_chave, meses_disponiveis)
    elif menu_opcao == "Arquivos/ID": arquivos.render(conn, ano_selecionado, mes_chave, meses_disponiveis)
    elif menu_opcao == "Usuários" and perfil_logado in ['a', 'g']: usuarios.render(conn, perfil_logado)
    conn.close()
except Exception as e:
    st.error(f"Erro operacional: {e}")

st.markdown("---")
st.caption(f"Ambiente: SEADLNX | Versao: 7.3 ({meses_disponiveis[mes_chave]}/{ano_selecionado})")

