# -*- coding: utf-8 -*-
import streamlit as st

def render(ano_selecionado, mes_chave):
    st.title("Modulo de Pagamentos")
    st.info(f"Faturamento e processamento do periodo {mes_chave}/{ano_selecionado}.")
