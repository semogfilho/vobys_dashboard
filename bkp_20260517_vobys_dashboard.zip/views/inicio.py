# -*- coding: utf-8 -*-
import streamlit as st
import pandas as pd

def render(conn, ano_selecionado, mes_chave, meses_disponiveis):
    # --- REDU��O E ZERAMENTO DE ESPA�OS NO TOPO VIA CSS ---
    st.markdown("""
        <style>
            /* Reduz o espacamento superior do bloco principal do Streamlit */
            .block-container {
                padding-top: 1rem !important;
                padding-bottom: 1rem !important;
            }
            /* Remove margens excessivas do primeiro elemento/titulo */
            div[data-testid="stVerticalBlock"] > div:first-child {
                margin-top: 0px !important;
                padding-top: 0px !important;
            }
            /* Ajusta a margem superior dos cards de metrica para subir o layout */
            div[data-testid="stMetric"] {
                margin-top: -10px !important;
            }
        </style>
    """, unsafe_allow_html=True)

    titulo_limpo = "Resumo de Integra\u00E7\u00E3o - Status Siafe"
    st.title(f".. {titulo_limpo}")
    
    subtitulo = f"Vis\u00E3o consolidada por tipo de requisi\u00E7\u00E3o de {meses_disponiveis[mes_chave]}/{ano_selecionado}."
    st.markdown(f"**{subtitulo}**")
    st.markdown("---")

    cursor = conn.cursor()
    
    sql = f"""
        SELECT 
            CASE 
                WHEN STATUS_VOBYS = 'P' THEN 'PENDENTE'
                WHEN STATUS_VOBYS = 'T' THEN 'TRANSMITIDO'
                WHEN STATUS_VOBYS = 'A' THEN 'ABERTO'
                WHEN STATUS_VOBYS = 'F' THEN 'FECHADO'
                WHEN STATUS_VOBYS = 'I' THEN 'INCONSISTENCIA DE CADASTRO'
                WHEN STATUS_VOBYS = 'O' THEN 'OUTRAS INCONSISTENCIA'
                WHEN STATUS_VOBYS = 'E' THEN 'ERRO'
                ELSE 'ABERTO'
            END AS STATUS,
            IND_TIPO_REQUISICAO AS TIPO,
            COUNT(*) AS QTD
        FROM sw_publico.SIAFE_EVENTO_INTEGRACAO
        WHERE ANO = {ano_selecionado} AND MES = {int(mes_chave)}
        GROUP BY STATUS_VOBYS, IND_TIPO_REQUISICAO
    """

    with st.spinner("Compilando metricas e estruturando painel executivo..."):
        try:
            cursor.execute(sql)
            rows = cursor.fetchall()
            
            if not rows:
                st.info(f"Nenhum dado de integracao Siafe encontrado para {meses_disponiveis[mes_chave]}/{ano_selecionado}.")
                cursor.close()
                return
                
            df_bruto = pd.DataFrame(rows, columns=['STATUS', 'TIPO', 'QTD'])
            df_bruto['TIPO'] = df_bruto['TIPO'].astype(str).str.upper().str.strip()
            df_bruto['STATUS'] = df_bruto['STATUS'].astype(str).str.upper().str.strip()
            
            df_pivot = df_bruto.pivot(index='STATUS', columns='TIPO', values='QTD').fillna(0).reset_index()
            
            for col in ['V1', 'V2', 'V3', 'V4']:
                if col not in df_pivot.columns:
                    df_pivot[col] = 0
            
            df_pivot = df_pivot.rename(columns={
                'V1': 'COLABORADOR',
                'V2': 'CREDITO',
                'V3': 'ORCAMENTARIO',
                'V4': 'PATRONAL'
            })
            
            df_pivot['TOTAL'] = df_pivot['COLABORADOR'] + df_pivot['CREDITO'] + df_pivot['ORCAMENTARIO'] + df_pivot['PATRONAL']
            
            total_col = df_pivot["COLABORADOR"].sum()
            total_cre = df_pivot["CREDITO"].sum()
            total_orc = df_pivot["ORCAMENTARIO"].sum()
            total_pat = df_pivot["PATRONAL"].sum()
            total_geral = df_pivot["TOTAL"].sum()
            
            total_abertos = df_pivot[df_pivot['STATUS'] == 'ABERTO']['TOTAL'].sum()
            total_erros = df_pivot[df_pivot['STATUS'].str.contains('ERRO|INCONSISTENCIA', na=False)]['TOTAL'].sum()
            
            pct_erros = (total_erros / total_geral * 100) if total_geral > 0 else 0.0
            pct_sucesso = 100.0 - pct_erros if total_geral > 0 else 100.0

            # CARDS DE METRICAS NO TOPO
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                st.metric(label=".. Volume Total", value=f"{int(total_geral)}")
            with c2:
                st.metric(label=".. Total Aberto", value=f"{int(total_abertos)}", delta=f"{(total_abertos/total_geral*100):.1f}% do Vol" if total_geral > 0 else "0%")
            with c3:
                label_card_erro = "Inconsist\u00EAncias / Erros"
                st.metric(label=f".. {label_card_erro}", value=f"{int(total_erros)}", delta=f"{pct_erros:.1f}% de Impacto", delta_color="inverse")
            with c4:
                label_card_sucesso = "Taxa de Efici\u00EAncia"
                st.metric(label=f". {label_card_sucesso}", value=f"{pct_sucesso:.1f}%")
            
            st.markdown("<br>", unsafe_allow_html=True)
            
            row_total = pd.DataFrame([{
                "STATUS": "TOTAL GERAL",
                "COLABORADOR": total_col,
                "CREDITO": total_cre,
                "ORCAMENTARIO": total_orc,
                "PATRONAL": total_pat,
                "TOTAL": total_geral
            }])
            
            df_final = pd.concat([df_pivot, row_total], ignore_index=True)
            
            if total_geral > 0:
                df_final["PERCENTUAL"] = (df_final["TOTAL"] / total_geral) * 100
            else:
                df_final["PERCENTUAL"] = 0.0

            # Tipagem forcada para inteiro para evitar decimais
            colunas_numericas = ['COLABORADOR', 'CREDITO', 'ORCAMENTARIO', 'PATRONAL', 'TOTAL']
            for col in colunas_numericas:
                df_final[col] = df_final[col].astype('int64')

            # ESTILIZACAO DAS LINHAS
            def aplicar_estilo_executivo(row):
                if row['STATUS'] == 'TOTAL GERAL':
                    return ['background-color: #343a40; color: #ffffff; font-weight: bold; border-top: 2px solid #000;'] * len(row)
                elif 'ERRO' in str(row['STATUS']) or 'INCONSISTENCIA' in str(row['STATUS']):
                    return ['background-color: #fce8e6; color: #a51d24; font-weight: 500;'] * len(row)
                elif row['STATUS'] == 'ABERTO':
                    return ['background-color: #e8f0fe; color: #1a73e8; font-weight: 500;'] * len(row)
                return [''] * len(row)

            df_estilizado = df_final.style.apply(aplicar_estilo_executivo, axis=1)

            label_orcamentario = "OR\u00C7AMENT\u00C1RIO"
            label_percentual = "PERCENTUAL \u0025"

            st.dataframe(
                df_estilizado, 
                use_container_width=True, 
                hide_index=True,
                column_config={
                    "STATUS": st.column_config.TextColumn(".. STATUS"),
                    "COLABORADOR": st.column_config.NumberColumn(".. COLABORADOR", format="%d"),
                    "CREDITO": st.column_config.NumberColumn(".. CREDITO", format="%d"),
                    "ORCAMENTARIO": st.column_config.NumberColumn(f"... {label_orcamentario}", format="%d"),
                    "PATRONAL": st.column_config.NumberColumn(".. PATRONAL", format="%d"),
                    "TOTAL": st.column_config.NumberColumn(".. TOTAL", format="%d"),
                    "PERCENTUAL": st.column_config.NumberColumn(f".. {label_percentual}", format="%.1f%%")
                }
            )
            
            # BARRA DE PROGRESSO VISUAL
            if pct_erros > 0:
                label_saude = "\u00CDndice de Sa\u00FAde de Integra\u00E7\u00E3o:"
                st.markdown(f"**{label_saude}**")
                st.progress(int(pct_sucesso))
                if pct_erros > 10:
                    msg_aviso = f"Aten\u00E7\u00E3o! O volume de inconsist\u00EAncias est\u00E1 em **{pct_erros:.1f}%** do total do per\u00EDodo."
                    st.warning(f".. {msg_aviso}")
            
        except Exception as e:
            st.error(f"Erro ao processar consulta no banco de dados: {e}")
    
    cursor.close()
