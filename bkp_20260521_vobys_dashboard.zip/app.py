# -*- coding: utf-8 -*-
import os
import sys
import streamlit as st
import oracledb

# Resolve o problema de caminhos para ficheiros dentro de pastas ocultas (.streamlit)
PASTA_STREAMLIT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".streamlit"))
if PASTA_STREAMLIT not in sys.path:
    sys.path.append(PASTA_STREAMLIT)

# Importação da camada visual de autenticação personalizada
import auth_ui

# Configuração da página e inicialização da barra lateral aberta por padrão
st.set_page_config(
    page_title="FOLHA - Operacao NTGD", 
    layout="wide",
    initial_sidebar_state="expanded"
)

# =========================================================================
# TRAVA DE SEGURANÇA NA BARRA LATERAL
# =========================================================================
# Se o utilizador NÃO estiver autenticado, renderiza a sidebar de login compacta e para aqui.
if auth_ui.gerenciar_sessao_fluxo():

    # ------------------------------------------------------------------------------
    # INJEÇÃO DE ESTILOS CSS (Aplica-se globalmente ao painel pós-login)
    # ------------------------------------------------------------------------------
    st.markdown("""
        <style>
            .block-container {
                padding-top: 3.5rem !important;
                padding-bottom: 1rem !important;
                padding-left: 2rem !important;
                padding-right: 2rem !important;
                margin-top: 0rem !important;
            }

            h1 {
                margin-top: 2rem !important;
                padding-top: 0rem !important;
                font-size: 36px !important;
                margin-bottom: 1.5rem !important;
            }

            .stTable, table, data-testid="stTable" {
                width: 100% !important;
                margin-bottom: 0rem !important;
            }

            div[data-testid="stTable"] table tbody tr td,
            div[data-testid="stTable"] td,
            .stTable td, 
            table td {
                font-size: 20px !important;
                font-weight: bold !important;
                line-height: 22px !important;
                padding-top: 2px !important;
                padding-bottom: 2px !important;
                height: 26px !important;
            }

            div[data-testid="stTable"] table thead tr th,
            div[data-testid="stTable"] th,
            .stTable th,
            table th {
                font-size: 18px !important;
                font-weight: 800 !important;
                line-height: 20px !important;
                padding-top: 4px !important;
                padding-bottom: 4px !important;
                background-color: #f9f9f9 !important;
            }

            div[data-testid="stDataFrame"] div {
                font-size: 20px !important;
            }

            section[data-testid="stSidebar"] div.st-emotion-cache-6qobrx {
                padding-top: 2rem !important;
                padding-left: 1rem !important;
                padding-right: 1rem !important;
            }

            div.stPlotlyChart {
                margin-top: 2rem !important;
                margin-left: auto;
                margin-right: auto;
                width: 100% !important;
            }

            div[data-testid="stRadio"] label {
                font-size: 20px !important;
            }
        </style>
    """, unsafe_allow_html=True)

    # ------------------------------------------------------------------------------
    # CARREGAMENTO SEGURADO DO SECRETS.TOML
    # ------------------------------------------------------------------------------
    try:
        DB_USER = st.secrets["database"]["db_user"]
        DB_PASS = st.secrets["database"]["db_pass"]
        DB_DSN = st.secrets["database"]["db_dsn"]
    except Exception as e:
        st.error(f"Erro Secrets: {e}")
        st.stop()

    # Importação dinâmica das views do ecossistema NTGD
    from views import inicio, grafico, pagamento, responsavel, arquivos

    # ------------------------------------------------------------------------------
    # ESTRUTURAÇÃO DO MENU LATERAL DO PAINEL
    # ------------------------------------------------------------------------------
    with st.sidebar:
        # Cabeçalho do menu lateral
        st.markdown("<h2 style='color: #015494; margin-top: -1rem;'>NTGD</h2>", unsafe_allow_html=True)
        st.write(f"👤 ` {st.session_state.get('usuario_logado', 'Usuário')} `")
        st.divider()

        # Seção de seleção temporal
        st.write("**Filtros do Periodo**")

        anos_disponiveis = [2024, 2025, 2026, 2027]
        ano_selecionado = st.selectbox("Selecione o Ano:", anos_disponiveis, index=2)

        meses_disponiveis = {
            "01": "Janeiro", "02": "Fevereiro", "03": "Marco", "04": "Abril",
            "05": "Maio", "06": "Junho", "07": "Julho", "08": "Agosto",
            "09": "Setembro", "10": "Outubro", "11": "Novembro", "12": "Dezembro"
        }

        mes_chave = st.selectbox(
            "Selecione o Mes:",
            list(meses_disponiveis.keys()),
            format_func=lambda x: meses_disponiveis[x],
            index=4
        )

        st.divider()
        
        # Seção de navegação interna
        st.write("**Navegacao**")
        menu_opcao = st.radio("", ["Inicio", "Grafico", "Pagamento", "Responsavel", "Arquivos/ID"])

        # Bloco espaçador dinâmico: Empurra tudo o que estiver abaixo para o rodapé do menu
        st.container(height=220, border=False)
        
        # Rodapé fixo do menu lateral
        st.divider()
        if st.button("Sair (Logout)", use_container_width=True, type="secondary"):
            st.session_state.autenticado = False
            st.session_state.usuario_logado = ""
            st.rerun()

    # ------------------------------------------------------------------------------
    # INTEGRALIZAÇÃO COM O BANCO DE DADOS ORACLE & EXECUÇÃO DAS VIEWS
    # ------------------------------------------------------------------------------
    try:
        conn = oracledb.connect(user=DB_USER, password=DB_PASS, dsn=DB_DSN)

        if menu_opcao == "Inicio":
            inicio.render(conn, ano_selecionado, mes_chave, meses_disponiveis)

        elif menu_opcao == "Grafico":
            grafico.render(conn, ano_selecionado, mes_chave, meses_disponiveis)

        elif menu_opcao == "Pagamento":
            pagamento.render(ano_selecionado, mes_chave)

        elif menu_opcao == "Responsavel":
            responsavel.render(conn, ano_selecionado, mes_chave, meses_disponiveis)

        elif menu_opcao == "Arquivos/ID":
            arquivos.render(conn, ano_selecionado, mes_chave, meses_disponiveis)

        conn.close()

    except Exception as e:
        st.error(f"Erro operacional: {e}")

    st.markdown("---")
    st.caption(f"Ambiente: SEADLNX | Versao: 7.3 ({meses_disponiveis[mes_chave]}/{ano_selecionado})")

