# -*- coding: utf-8 -*-
import streamlit as st
import sys
import os

# Mapeia o caminho interno para localizar o auth_manager
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
import auth_manager as am

def renderizar_tela_autenticacao():
    # Injeta CSS específico para encolher e estilizar o formulário de login na sidebar
    st.markdown("""
        <style>
            /* Limita a largura dos inputs e botões especificamente no momento do login */
            section[data-testid="stSidebar"] div.stTextInput,
            section[data-testid="stSidebar"] div.stButton,
            section[data-testid="stSidebar"] .stAlert {
                max-width: 260px !important;
                margin-left: auto !important;
                margin-right: auto !important;
            }
            
            /* Remove margens excessivas para compactar o card */
            section[data-testid="stSidebar"] div.stTextInput {
                margin-bottom: -0.5rem !important;
            }
        </style>
    """, unsafe_allow_html=True)

    # Deixa a tela principal totalmente limpa (sem caixas grandes no meio)
    st.empty()
    
    # Desenha o formulário compacto de forma restrita na barra lateral
    with st.sidebar:
        st.markdown("<h2 style='color: #015494; text-align: center; margin-top: 0rem;'>🔒 Entrar</h2>", unsafe_allow_html=True)
        st.markdown("<p style='text-align: center; font-size: 14px; color: #666;'>Identifique-se para acessar:</p>", unsafe_allow_html=True)
        
        usuario = st.text_input("Username:", key="login_user")
        senha = st.text_input("Password:", type="password", key="login_pass")
        
        st.write("") # Pequeno espaçador de respiro
        
        if st.button("Login", use_container_width=True):
            if usuario and senha:
                if am.verificar_credenciais(usuario, senha):
                    st.session_state.autenticado = True
                    st.session_state.usuario_logado = usuario
                    st.rerun()
                else:
                    st.error("Usuário ou senha incorretos.")
            else:
                st.warning("Preencha todos os campos.")

def gerenciar_sessao_fluxo():
    if "autenticado" not in st.session_state:
        st.session_state.autenticado = False
    if "usuario_logado" not in st.session_state:
        st.session_state.usuario_logado = ""
        
    if not st.session_state.autenticado:
        renderizar_tela_autenticacao()
        return False
    else:
        return True

