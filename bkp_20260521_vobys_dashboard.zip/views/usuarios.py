# -*- coding: utf-8 -*-
import streamlit as st
import oracledb

def render(conn, perfil_usuario):
    st.title("⚙️ Gerenciamento de Usuários")
    
    # -------------------------------------------------------------------------
    # ABA 1: LISTAR E EXCLUIR USUÁRIOS (Disponível para 'a' e 'g')
    # -------------------------------------------------------------------------
    tab_listar, tab_cadastrar = st.tabs(["📋 Usuários Cadastrados", "➕ Cadastrar Novo Usuário"])
    
    with tab_listar:
        st.write("### Lista de Acessos")
        try:
            cursor = conn.cursor()
            # Substitua 'usuarios' pelo nome real da sua tabela de credenciais
            cursor.execute("SELECT login, nome, tipo FROM usuarios ORDER BY nome")
            usuarios = cursor.fetchall()
            cursor.close()
            
            if usuarios:
                for usu in usuarios:
                    u_login, u_nome, u_tipo = usu
                    
                    # Label amigável para o tipo
                    tipo_desc = "Administrador" if u_tipo == 'a' else "Gerente" if u_tipo == 'g' else "Comum"
                    
                    col_info, col_btn = st.columns([4, 1])
                    with col_info:
                        st.markdown(f"**{u_nome}** (`{u_login}`) - Perfil: *{tipo_desc}*")
                    
                    with col_btn:
                        # APENAS administrador ('a') pode excluir
                        if perfil_usuario == 'a':
                            if st.button(f"Excluir", key=f"del_{u_login}", type="primary", use_container_width=True):
                                try:
                                    cur_del = conn.cursor()
                                    cur_del.execute("DELETE FROM usuarios WHERE login = :login", [u_login])
                                    conn.commit()
                                    cur_del.close()
                                    st.success(f"Usuário {u_login} excluído!")
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"Erro ao excluir: {e}")
                        else:
                            # Se for gerente, o botão fica desabilitado
                            st.button(f"Bloqueado", key=f"dis_{u_login}", disabled=True, use_container_width=True)
                    st.divider()
            else:
                st.info("Nenhum usuário cadastrado.")
        except Exception as e:
            st.error(f"Erro ao buscar usuários: {e}")

    # -------------------------------------------------------------------------
    # ABA 2: CADASTRAR USUÁRIO (Visualização 'a' e 'g', mas AÇÃO apenas 'a')
    # -------------------------------------------------------------------------
    with tab_cadastrar:
        st.write("### Inserir Novo Usuário no Sistema")
        
        # Formulário de cadastro
        with st.form("form_cadastro_usuario", clear_on_submit=True):
            novo_login = st.text_input("Login (Usuário):").strip()
            novo_nome = st.text_input("Nome Completo:").strip()
            
            opcoes_tipo = {"Administrador": "a", "Gerente": "g", "Comum": "c"}
            tipo_selecionado = st.selectbox("Tipo de Perfil:", list(opcoes_tipo.keys()))
            novo_tipo = opcoes_tipo[tipo_selecionado]
            
            # Se quiser colocar uma senha padrão na criação, adicione aqui
            nova_senha = st.text_input("Senha Inicial:", type="password") 
            
            btn_salvar = st.form_submit_button("Salvar Usuário", use_container_width=True)
            
            if btn_salvar:
                # Validação de perfil em nível de código (Segurança extra)
                if perfil_usuario != 'a':
                    st.error("❌ Apenas usuários administradores ('a') podem adicionar novos usuários.")
                elif not novo_login or not novo_nome or not nova_senha:
                    st.warning("⚠️ Por favor, preencha todos os campos.")
                else:
                    try:
                        cur_ins = conn.cursor()
                        # Ajuste as colunas de acordo com sua tabela (Exemplo incluindo a senha)
                        sql = "INSERT INTO usuarios (login, nome, tipo, senha) VALUES (:1, :2, :3, :4)"
                        cur_ins.execute(sql, [novo_login, novo_nome, novo_tipo, nova_senha])
                        conn.commit()
                        cur_ins.close()
                        st.success(f"🎉 Usuário {novo_nome} cadastrado com sucesso!")
                    except Exception as e:
                        st.error(f"Erro ao inserir no banco: {e}")

