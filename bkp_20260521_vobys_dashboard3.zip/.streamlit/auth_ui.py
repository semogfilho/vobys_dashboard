# -*- coding: utf-8 -*-
import os
import streamlit as st
import hashlib
import toml

CAMINHO_ATUAL = os.path.dirname(__file__)
CAMINHO_USERS_TOML = os.path.abspath(os.path.join(CAMINHO_ATUAL, "users.toml")) if CAMINHO_ATUAL.endswith(".streamlit") else os.path.abspath(os.path.join(CAMINHO_ATUAL, ".streamlit", "users.toml"))

def carregar_usuarios_toml():
    if not os.path.exists(CAMINHO_USERS_TOML): return {"usuario": {}}
    return toml.load(CAMINHO_USERS_TOML)

def salvar_usuarios_toml(dados):
    with open(CAMINHO_USERS_TOML, "w", encoding="utf-8") as f: toml.dump(dados, f)

def verificar_credenciais(usuario, senha):
    dados = carregar_usuarios_toml()
    usuarios_dict = dados.get("usuario", {})
    usuario_limpo = usuario.strip().lower()
    if usuario_limpo in usuarios_dict:
        user_data = usuarios_dict[usuario_limpo]
        senha_hash_digitada = hashlib.sha256(senha.strip().encode('utf-8')).hexdigest()
        if senha_hash_digitada == user_data.get("senha_hash"):
            return (usuario_limpo, user_data.get("nome", ""), user_data.get("tipo"), str(user_data.get("requer_reset", "nao")).replace('"', '').replace("'", "").strip().lower())
    return None

def desenhar_formulario_reset(login_alvo):
    st.markdown("<h3 style='color: #015494; margin-top: 0px;'>🔑 Nova Senha</h3>", unsafe_allow_html=True)
    senha_nova = st.text_input("Nova Senha:", type="password", key="pwd_nova")
    senha_confirma = st.text_input("Confirme a Senha:", type="password", key="pwd_conf")
    if st.button("Gravar Nova Senha", use_container_width=True, type="primary"):
        if senha_nova != senha_confirma: st.error("❌ As senhas não conferem!")
        else:
            dados = carregar_usuarios_toml()
            dados["usuario"][login_alvo]["senha_hash"] = hashlib.sha256(senha_nova.strip().encode('utf-8')).hexdigest()
            dados["usuario"][login_alvo]["requer_reset"] = "nao"
            salvar_usuarios_toml(dados)
            st.session_state.autenticado = True
            st.session_state.usuario_em_reset = None
            st.rerun()

def gerenciar_sessao_fluxo():
    if st.session_state.usuario_em_reset:
        desenhar_formulario_reset(st.session_state.usuario_em_reset)
        return
    st.markdown("<h3 style='color: #015494; margin-top: 0px; margin-bottom: 5px;'>🔒 Entrar</h3>", unsafe_allow_html=True)
    usuario_input = st.text_input("Username:", key="input_user").strip()
    senha_input = st.text_input("Password:", type="password", key="input_pass")
    if st.button("Login", use_container_width=True, type="secondary"):
        dados = verificar_credenciais(usuario_input, senha_input)
        if dados:
            login_bd, nome_bd, tipo_bd, flag_reset = dados
            if flag_reset in ["sim", "true", "1"]:
                st.session_state.usuario_em_reset = login_bd
                st.rerun()
            else:
                st.session_state.usuario_logado = login_bd
                st.session_state.nome_usuario = str(nome_bd)
                st.session_state.perfil_usuario = str(tipo_bd).lower().strip()
                st.session_state.autenticado = True
                # [BLINDAGEM] Ancoragem na URL
                st.query_params["token_auth"] = "ativo"
                st.query_params["user"] = login_bd
                st.query_params["nome"] = str(nome_bd)
                st.query_params["perfil"] = str(tipo_bd).lower().strip()
                st.rerun()
        else: st.error("Usuário ou senha incorretos.")


