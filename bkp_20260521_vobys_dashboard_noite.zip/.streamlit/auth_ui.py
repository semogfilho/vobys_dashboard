# -*- coding: utf-8 -*-
import os
import streamlit as st
import hashlib
import toml

# Caminho absoluto para a raiz do projeto e aponta para .streamlit/users.toml
RAIZ_PROJETO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CAMINHO_USERS_TOML = os.path.join(RAIZ_PROJETO, ".streamlit", "users.toml")

def carregar_usuarios_toml():
    if not os.path.exists(CAMINHO_USERS_TOML):
        return {"usuario": {}}
    return toml.load(CAMINHO_USERS_TOML)

def verificar_credenciais(usuario, senha):
    dados = carregar_usuarios_toml()
    usuarios_dict = dados.get("usuario", {})
    usuario_limpo = usuario.strip().lower()
    
    if usuario_limpo in usuarios_dict:
        user_data = usuarios_dict[usuario_limpo]
        senha_hash_digitada = hashlib.sha256(senha.strip().encode('utf-8')).hexdigest()
        
        if senha_hash_digitada == user_data.get("senha_hash"):
            return (usuario_limpo, user_data.get("nome", ""), user_data.get("tipo"), str(user_data.get("requer_reset", "nao")))
    return None

def gerenciar_sessao_fluxo():
    st.markdown("<h3 style='color: #015494;'>🔒 Entrar</h3>", unsafe_allow_html=True)
    usuario_input = st.text_input("Username:", key="input_user").strip()
    senha_input = st.text_input("Password:", type="password", key="input_pass")
    
    if st.button("Login", use_container_width=True, type="secondary"):
        dados = verificar_credenciais(usuario_input, senha_input)
        if dados:
            login_bd, nome_bd, tipo_bd, flag_reset = dados
            st.session_state.usuario_logado = login_bd
            st.session_state.nome_usuario = str(nome_bd)
            st.session_state.perfil_usuario = str(tipo_bd).lower().strip()
            st.session_state.autenticado = True
            st.rerun() 
        else:
            st.error("Usuário ou senha incorretos.")

