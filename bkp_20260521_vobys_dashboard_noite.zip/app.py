# -*- coding: utf-8 -*-
import os
import sys
import streamlit as st
import oracledb

# --- AJUSTE DE PATH ---
PASTA_STREAMLIT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".streamlit"))
if PASTA_STREAMLIT not in sys.path:
    sys.path.append(PASTA_STREAMLIT)

import auth_ui
from views import inicio, grafico, pagamento, responsavel, arquivos, usuarios

st.set_page_config(page_title="FOLHA - Operacao NTGD", layout="wide")

# Inicialização
if "autenticado" not in st.session_state: st.session_state.autenticado = False

# Trava de Segurança
if not st.session_state.autenticado:
    with st.sidebar:
        auth_ui.gerenciar_sessao_fluxo()
    st.markdown("<h3 style='color: #666; font-weight: normal; margin-top: 5rem; text-align: center;'>🔒 Aguardando identificação no menu lateral...</h3>", unsafe_allow_html=True)
    st.stop()

# Sidebar e Navegação
with st.sidebar:
    st.write(f"👤 **{st.session_state.get('nome_usuario', 'User')}**")
    st.divider()
    
    ano_selecionado = st.selectbox("Ano de Referência:", [2025, 2026], index=1)
    mes_chave = st.selectbox("Mês:", ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"], index=4)
    st.divider()
    
    perfil_logado = st.session_state.get('perfil_usuario', 'c')
    opcoes = ["Inicio", "Grafico", "Pagamento", "Responsavel", "Arquivos/ID"]
    if perfil_logado in ['a', 'g']: opcoes.append("Usuários")
    menu_opcao = st.radio("Navegação:", opcoes)
    
    st.divider()
    if st.button("Sair (Logout)", use_container_width=True):
        st.session_state.clear()
        st.rerun()

# RENDERIZAÇÃO
try:
    conn = oracledb.connect(
        user=st.secrets["database"]["db_user"],
        password=st.secrets["database"]["db_pass"],
        dsn=st.secrets["database"]["db_dsn"]
    )
    
    # As views de banco recebem os parâmetros necessários
    if menu_opcao == "Inicio": inicio.render(conn, ano_selecionado, mes_chave, {})
    elif menu_opcao == "Grafico": grafico.render(conn, ano_selecionado, mes_chave, {})
    elif menu_opcao == "Pagamento": pagamento.render(ano_selecionado, mes_chave)
    elif menu_opcao == "Responsavel": responsavel.render(conn, ano_selecionado, mes_chave, {})
    elif menu_opcao == "Arquivos/ID": arquivos.render(conn, ano_selecionado, mes_chave, {})
    
    # AQUI ESTÁ O AJUSTE: Apenas 2 argumentos (conn e perfil) 
    # como definido no seu usuarios.py autônomo
    elif menu_opcao == "Usuários" and perfil_logado in ['a', 'g']: 
        usuarios.render(conn, perfil_logado)
    
    conn.close()
except Exception as e:
    st.error(f"Erro de conexão: {e}")

