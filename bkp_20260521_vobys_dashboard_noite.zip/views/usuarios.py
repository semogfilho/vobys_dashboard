# -*- coding: utf-8 -*-
import streamlit as st
import os
import toml
import hashlib

# Caminho absoluto para o TOML
CAMINHO_ATUAL = os.path.dirname(__file__)
if CAMINHO_ATUAL.endswith(".streamlit") or CAMINHO_ATUAL.endswith("views"):
    CAMINHO_USERS_TOML = os.path.abspath(os.path.join(CAMINHO_ATUAL, "..", ".streamlit", "users.toml"))
else:
    CAMINHO_USERS_TOML = os.path.abspath(os.path.join(CAMINHO_ATUAL, ".streamlit", "users.toml"))

def carregar_usuarios():
    if not os.path.exists(CAMINHO_USERS_TOML):
        return {"usuario": {}}
    return toml.load(CAMINHO_USERS_TOML)

def salvar_usuarios(dados):
    with open(CAMINHO_USERS_TOML, "w", encoding="utf-8") as f:
        toml.dump(dados, f)

def render(conn, perfil_logado):
    if "msg_sucesso_reset" not in st.session_state:
        st.session_state.msg_sucesso_reset = None

    st.markdown("<h2>⚙️ Gerenciamento de Usuários</h2>", unsafe_allow_html=True)
    
    aba_listar, aba_cadastrar = st.tabs(["📋 Usuários", "➕ Cadastrar"])
    
    dados_toml = carregar_usuarios()
    usuarios_dict = dados_toml.get("usuario", {})

    with aba_listar:
        if st.session_state.msg_sucesso_reset:
            st.success(st.session_state.msg_sucesso_reset)
            st.session_state.msg_sucesso_reset = None

        for login, info in usuarios_dict.items():
            tipo_user = info.get("tipo", "c")
            nome_user = info.get("nome", "Sem Nome")
            status_reset_bruto = info.get("requer_reset", "nao")
            esta_resetado = str(status_reset_bruto).strip().lower() in ["sim", "true", "1"]
            
            col1, col2, col3 = st.columns([3, 2, 2])
            with col1:
                st.write(f"👤 **{nome_user}** ({login}) {'🔴' if esta_resetado else ''}")
            with col2:
                label = "Administrador" if tipo_user == "a" else "Gerente" if tipo_user == "g" else "Comum"
                st.write(f"Perfil: *{label}*")
            with col3:
                if perfil_logado == "g" and tipo_user == "a":
                    st.write("🔒 Restrito")
                else:
                    if st.button("Forçar Reset", key=f"btn_rst_{login}", disabled=esta_resetado):
                        senha_padrao = "sead@ntgd"
                        dados_toml["usuario"][login]["requer_reset"] = "sim"
                        dados_toml["usuario"][login]["senha_hash"] = hashlib.sha256(senha_padrao.encode('utf-8')).hexdigest()
                        salvar_usuarios(dados_toml)
                        st.session_state.msg_sucesso_reset = f"Sucesso! Senha provisória: `{senha_padrao}`"
                        st.rerun()

    with aba_cadastrar:
        novo_login = st.text_input("Login:", key="nv_login").strip().lower()
        novo_nome = st.text_input("Nome:", key="nv_nome").strip()
        perfil_map = {"Administrador": "a", "Gerente": "g", "Comum": "c"} if perfil_logado == "a" else {"Gerente": "g", "Comum": "c"}
        perfil_sel = st.selectbox("Perfil:", list(perfil_map.keys()))
        
        if st.button("Salvar Novo Usuário"):
            if novo_login in usuarios_dict:
                st.error("Login já existe!")
            else:
                dados_toml["usuario"][novo_login] = {
                    "nome": novo_nome, "senha_hash": hashlib.sha256("sead@ntgd".encode()).hexdigest(),
                    "tipo": perfil_map[perfil_sel], "requer_reset": "sim"
                }
                salvar_usuarios(dados_toml)
                st.success("Usuário salvo!")
                st.rerun()

